//
//  ViewController.h
//  ImageAnimation
//
//  Created by Kumar on 20/02/16.
//  Copyright (c) 2016 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

