//
//  UIViewController+ImageAnimation.h
//  CategoryExample
//
//  Created by Alet Viegas on 4/1/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (ImageAnimation)
-(void)imageanimation;
-(void)startAnimation;
-(void)stopAnimation;

@end
