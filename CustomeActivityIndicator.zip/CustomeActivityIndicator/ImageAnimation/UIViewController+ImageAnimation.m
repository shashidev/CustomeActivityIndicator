//
//  UIViewController+ImageAnimation.m
//  CategoryExample
//
//  Created by Alet Viegas on 4/1/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import "UIViewController+ImageAnimation.h"
#define ARRAYCAPACITY 16

@implementation UIViewController (ImageAnimation)

-(void)imageanimation
{
    NSArray *imageNames = @[@"img1.png", @"img2.png", @"img3.png", @"img4.png",
                            @"img5.png", @"img6.png", @"img7.png", @"img8.png",
                            @"img9.png", @"img10.png", @"img11.png", @"img12.png"];
    NSMutableArray *images = [[NSMutableArray alloc] init];
    
    for (int i = 1; i < imageNames.count; i++)
    {
       [images addObject:[UIImage imageNamed:[imageNames objectAtIndex:i]]];
        
    }
    
    // Normal Animation
    UIImageView *animationImageView = [[UIImageView alloc] initWithFrame:CGRectMake(90, 95, 100, 100)];
    animationImageView.tag=100;
    animationImageView.hidden = NO;
    animationImageView.animationImages = images;
    animationImageView.animationDuration = 1;

    [self.view addSubview:animationImageView];
    
    
}
-(void)startAnimation
{
    UIImageView *image = [self.view viewWithTag:100];
    [image startAnimating];
    image.hidden = NO;
    
}
-(void)stopAnimation
{
    UIImageView *image = [self.view viewWithTag:100];
    [image stopAnimating];
    image.hidden = YES;
}

@end
