//
//  ViewController.m
//  ImageAnimation
//
//  Created by Kumar on 20/02/16.
//  Copyright (c) 2016 Kumar. All rights reserved.
//

#import "ViewController.h"
#import "UIViewController+ImageAnimation.h"
#define IMG_COUNT 12
@interface ViewController ()
{
    NSMutableArray *imageArray;
}
@property (strong, nonatomic) IBOutlet UIImageView *myImageView;
- (IBAction)startAnimation:(id)sender;
- (IBAction)stopAnimation:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
[self imageanimation];
    
}


- (IBAction)startAnimation:(id)sender {

  [self startAnimation];
}

- (IBAction)stopAnimation:(id)sender {
  [self stopAnimation];
}
@end
